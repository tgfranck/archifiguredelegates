package com.archimatetool.csv.export;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {

    private static final String BUNDLE_NAME = "com.archimatetool.csv.export.messages"; //$NON-NLS-1$

    public static String CSVExportProvider_0;

    public static String ExportAsCSVPage_0;

    public static String ExportAsCSVPage_1;

    public static String ExportAsCSVPage_10;

    public static String ExportAsCSVPage_11;

    public static String ExportAsCSVPage_12;

    public static String ExportAsCSVPage_13;

    public static String ExportAsCSVPage_14;

    public static String ExportAsCSVPage_15;

    public static String ExportAsCSVPage_2;

    public static String ExportAsCSVPage_3;

    public static String ExportAsCSVPage_4;

    public static String ExportAsCSVPage_5;

    public static String ExportAsCSVPage_6;

    public static String ExportAsCSVPage_7;

    public static String ExportAsCSVPage_8;

    public static String ExportAsCSVPage_9;

    public static String ExportAsCSVWizard_0;

    public static String ExportAsCSVWizard_1;

    public static String ExportAsCSVWizard_2;

    public static String ExportAsCSVWizard_3;

    public static String ExportAsCSVWizard_4;
    static {
        // initialize resource bundle
        NLS.initializeMessages(BUNDLE_NAME, Messages.class);
    }

    private Messages() {
    }
}
