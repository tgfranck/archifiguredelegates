package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;

public class EquipmentBoxFigureDelegate extends BoxFigureDelegate {

	public EquipmentBoxFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 17);
	}

}
