package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;
import com.archimatetool.editor.diagram.figures.RectangleFigureDelegate;

public class LocationRectangleFigureDelegate extends RectangleFigureDelegate {

	public LocationRectangleFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 11);
	}

}
