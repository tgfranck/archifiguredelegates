package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;
import com.archimatetool.editor.diagram.figures.RoundedRectangleFigureDelegate;

public class CapabilityRoundedRectangleFigureDelegate extends RoundedRectangleFigureDelegate {

	public CapabilityRoundedRectangleFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 14);
	}

}
