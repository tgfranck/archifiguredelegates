package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;

public class DeviceBoxFigureDelegate extends BoxFigureDelegate {

	public DeviceBoxFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 15);
	}

}
