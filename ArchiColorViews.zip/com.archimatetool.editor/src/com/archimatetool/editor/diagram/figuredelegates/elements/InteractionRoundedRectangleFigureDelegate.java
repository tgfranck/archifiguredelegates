package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;
import com.archimatetool.editor.diagram.figures.RoundedRectangleFigureDelegate;

public class InteractionRoundedRectangleFigureDelegate extends RoundedRectangleFigureDelegate {

	public InteractionRoundedRectangleFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 15);
	}

}
