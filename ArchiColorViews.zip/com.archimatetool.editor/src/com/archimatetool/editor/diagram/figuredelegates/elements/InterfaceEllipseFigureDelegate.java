package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.EllipseFigureDelegate;
import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;

public class InterfaceEllipseFigureDelegate extends EllipseFigureDelegate {

	public InterfaceEllipseFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner);
	}

}
