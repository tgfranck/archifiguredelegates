package com.archimatetool.editor.diagram.figuredelegates.diagram;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;
import com.archimatetool.editor.diagram.figures.RectangleFigureDelegate;

public class DiagramModelReferenceRectangleFigureDelegate extends RectangleFigureDelegate {

	public DiagramModelReferenceRectangleFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 17);
	}

}
