package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;
import com.archimatetool.editor.diagram.figures.RoundedRectangleFigureDelegate;

public class FunctionRoundedRectangleFigureDelegate extends RoundedRectangleFigureDelegate {

	public FunctionRoundedRectangleFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 15);
	}

}
