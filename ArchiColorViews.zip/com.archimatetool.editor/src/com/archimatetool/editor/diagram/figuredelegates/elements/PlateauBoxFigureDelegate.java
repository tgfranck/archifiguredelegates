package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;

public class PlateauBoxFigureDelegate extends BoxFigureDelegate {

	public PlateauBoxFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 17);
	}

}
