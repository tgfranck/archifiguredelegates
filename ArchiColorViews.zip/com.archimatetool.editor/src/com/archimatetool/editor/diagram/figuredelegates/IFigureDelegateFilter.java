package com.archimatetool.editor.diagram.figuredelegates;

public interface IFigureDelegateFilter {
	
	public void apply(IFigureDelegate delegate);

}
