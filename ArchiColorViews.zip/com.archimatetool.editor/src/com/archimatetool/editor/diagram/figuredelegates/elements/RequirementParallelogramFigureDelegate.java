package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;

public class RequirementParallelogramFigureDelegate extends ParallelogramFigureDelegate {

	public RequirementParallelogramFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, false);
	}

}
