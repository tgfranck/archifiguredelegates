package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;

public class FacilityBoxFigureDelegate extends BoxFigureDelegate {

	public FacilityBoxFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 15);
	}

}
