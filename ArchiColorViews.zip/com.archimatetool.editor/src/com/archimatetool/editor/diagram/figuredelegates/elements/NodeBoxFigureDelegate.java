package com.archimatetool.editor.diagram.figuredelegates.elements;

import com.archimatetool.editor.diagram.figures.IDiagramModelObjectFigure;

public class NodeBoxFigureDelegate extends BoxFigureDelegate {

	public NodeBoxFigureDelegate(IDiagramModelObjectFigure owner) {
		super(owner, 0);
	}

}
